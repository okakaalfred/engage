define( function ( require ) {

	"use strict";

	return {
		app_slug : 'group-kenya',
		wp_ws_url : 'http://www.groupkenya.com/wp-appkit-api/group-kenya',
		wp_url : 'http://www.groupkenya.com',
		theme : 'gk-android',
		version : '1.0',
		app_title : 'Group Kenya',
		app_platform : 'android',
		gmt_offset : 3,
		debug_mode : 'off',
		auth_key : '903dc11b62cb6c7a32bfb640661b5a790ebd8e54f244067ade43680541953dde',
		options : {"refresh_interval":0},
		theme_settings : [],
		addons : []
	};

});
